(function($){

	$(document).ready(function(e){

		$('label').inFieldLabels();

	});
	
})(jQuery);