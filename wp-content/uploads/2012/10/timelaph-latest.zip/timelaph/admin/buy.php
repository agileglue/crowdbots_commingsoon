	<?php $upthemes =  THEME_DIR.'/admin/';?>

	<script type="text/javascript">
	    var upThemes = "<?php echo THEME_DIR; ?>";
	</script>

    <div id="upthemes_framework" class="wrap">
    
		<?php upfw_admin_header(); ?>

        <div id="up_buy">
            <iframe src="http://upthemes.com/buy-themes/" frameborder="0"></iframe>
        </div>

    </div>
